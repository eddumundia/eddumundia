<h3>Hey 👋, I'm <a href="http://eddumundia.com/">Edward Mundia</a></h3>



<h3>Connect with me</h3>

[<img src="https://img.shields.io/badge/twitter-%231DA1F2.svg?&style=for-the-badge&logo=twitter&logoColor=white" />](https://twitter.com/eddumundia)  [<img src="https://img.shields.io/badge/linkedin-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white" />](https://www.linkedin.com/in/edward-mundia-47133b3b/) [<img src = "https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white">](https://www.instagram.com/eddumundia/) [<img src = "https://img.shields.io/badge/facebook-%231877F2.svg?&style=for-the-badge&logo=facebook&logoColor=white">](https://www.facebook.com/eddumundia) ![Visits Badge](https://badges.pufler.dev/visits/puf17640/git-badges?style=for-the-badge ) 

<p>Am an experienced Senior Software Engineer with a demonstrated history of working in the research industry. Currently working as senior software developer at <a href="https://kemri-wellcome.org/" target="_blank" class="btn-link" >KEMRI WELLCOME TRUST</a>. I have managed to work with different companies as software developer in different capacities which include;
	<a href="https://www.aimgroup.co.tz/" target="_blank" class="btn-link">AIM Group Tanzania,</a>
	<a href="https://web.facebook.com/iran.medical.clinic.kenya/"  target="_blank" class="btn-link">Iran Medical Clinic,</a>
	<a href="https://linksoft.co.ke/" target="_blank" class="btn-link">linksoft telecommunication,</a>
	<a href="https://www.thedigitalgroup.biz/"target="_blank" class="btn-link">Digital Consulting Group</a>
  </p>
   <ul>
        <li>🔭 I’m currently working on my health and making customers happy</li>
        <li>🌱 I’m currently learning Machine learning, AI, GraphSQL, R and Stata</li>
        <li>👯 I’m currently a student at Google Africa Android developer scholarship (GAADS)</li>
        <li>👯 I’m setting up and expanding photography and videography</li>
        <li>📫 How to reach me: eddumundia@gmail.com</li>
        <li>😄 Pronouns: he/him</li>
        <li>⚡ Fun fact: Lets talk about bikes and cars(Subaru)</li>
  </ul>


  <h3>Languages and tools</h3>
  		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/vue/vue.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/5c058a388828bb5fde0bcafd4bc867b5bb3f26f3/topics/graphql/graphql.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/cpp/cpp.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/python/python.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mysql/mysql.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/firebase/firebase.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>
		<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/php/php.png"></code>


<p align = "center">
  <img src = "https://github-readme-stats.vercel.app/api?username=eddumundia&show_icons=true">
  <img src = "https://github-readme-stats.vercel.app/api/top-langs/?username=eddumundia">
</p>




